#!/bin/bash
set -euo pipefail

# ==================================================
# COLORS
# ==================================================

RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
MAGENTA="\e[35m"
WHITE="\e[97m"
BLUE="\e[34m"
BOLD="\e[1m"
RESET="\e[0m"

YQ="/usr/local/bin/yq"

# ==================================================
# HEADER
# ==================================================

echo -e "${MAGENTA}${BOLD}"
echo "=================================================="
echo "        MARIADB + PLUGINS AUTO WIZARD"
echo "=================================================="
echo -e "${RESET}"

# ==================================================
# ROOT CHECK
# ==================================================

if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Erreur : exécution en root requise.${RESET}"
  exit 1
fi

# ==================================================
# INSTALL DEPENDENCIES
# ==================================================

echo -e "${CYAN}${BOLD}>>> Installation des dépendances...${RESET}"
apt update -qq
apt install -y mariadb-server wget >/dev/null

systemctl enable mariadb
systemctl start mariadb

# ==================================================
# INSTALL YQ v4
# ==================================================

if [ ! -x "$YQ" ] || ! "$YQ" --version 2>/dev/null | grep -q "v4"; then

  echo -e "${CYAN}Installation de yq v4...${RESET}"

  apt remove -y yq >/dev/null 2>&1 || true
  rm -f /usr/bin/yq
  rm -f /usr/local/bin/yq

  wget -q https://github.com/mikefarah/yq/releases/latest/download/yq_linux_amd64 -O "$YQ"
  chmod +x "$YQ"

  if ! "$YQ" --version | grep -q "v4"; then
    echo -e "${RED}Erreur installation yq.${RESET}"
    exit 1
  fi

  echo -e "${GREEN}✔ yq v4 installé${RESET}"

else
  echo -e "${GREEN}✔ yq v4 déjà présent${RESET}"
fi

# ==================================================
# ROOT PASSWORD
# ==================================================

echo -e "${YELLOW}${BOLD}>>> Configuration du mot de passe ROOT MariaDB${RESET}"

read -s -p "Nouveau mot de passe root : " ROOT_PASS
echo
read -s -p "Confirmation : " ROOT_PASS_CONFIRM
echo

if [ "$ROOT_PASS" != "$ROOT_PASS_CONFIRM" ]; then
  echo -e "${RED}Les mots de passe ne correspondent pas.${RESET}"
  exit 1
fi

echo -e "${CYAN}Sécurisation de MariaDB...${RESET}"

mysql -u root <<EOF
ALTER USER 'root'@'localhost' IDENTIFIED BY '$ROOT_PASS';
DELETE FROM mysql.user WHERE User='';
DROP DATABASE IF EXISTS test;
DELETE FROM mysql.db WHERE Db='test' OR Db='test\\_%';
FLUSH PRIVILEGES;
EOF

echo -e "${GREEN}✔ MariaDB sécurisé${RESET}"

# ==================================================
# DATABASE CREATION
# ==================================================

echo -e "${MAGENTA}${BOLD}>>> Création des bases de données${RESET}"

read -p "Combien de databases voulez-vous créer ? " DB_COUNT

declare -A DB_CREDENTIALS

for ((i=1;i<=DB_COUNT;i++)); do

  echo -e "${WHITE}--- Database $i ---${RESET}"

  read -p "Nom database : " DB_NAME
  read -p "Utilisateur : " DB_USER
  read -s -p "Mot de passe : " DB_PASS
  echo

  mysql -u root -p"$ROOT_PASS" <<EOF
CREATE DATABASE IF NOT EXISTS \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'localhost';
FLUSH PRIVILEGES;
EOF

  echo -e "${GREEN}✔ Base $DB_NAME créée${RESET}"

  DB_CREDENTIALS["$DB_NAME"]="$DB_USER:$DB_PASS"

done

# ==================================================
# BACKUP SYSTEM
# ==================================================

backup_file() {
  [ -f "$1" ] && cp "$1" "$1.bak"
}

rollback() {
  echo -e "${RED}Erreur détectée. Rollback...${RESET}"
  for f in "${MODIFIED_FILES[@]:-}"; do
    [ -f "$f.bak" ] && mv "$f.bak" "$f"
  done
  exit 1
}

trap rollback ERR
MODIFIED_FILES=()

# ==================================================
# PLUGINS
# ==================================================

PLUGIN_DIR="/opt/minecraft/plugins"

declare -A PLUGINS=(
  ["LuckPerms"]="$PLUGIN_DIR/LuckPerms/config.yml"
  ["Jobs"]="$PLUGIN_DIR/Jobs/generalConfig.yml"
  ["Towny"]="$PLUGIN_DIR/Towny/settings/database.yml"
  ["AuraSkills"]="$PLUGIN_DIR/AuraSkills/config.yml"
)

# ==================================================
# CONFIGURATION LOOP
# ==================================================

for plugin in "${!PLUGINS[@]}"; do

  CONFIG="${PLUGINS[$plugin]}"

  [ ! -f "$CONFIG" ] && continue

  echo -e "${YELLOW}Plugin : $plugin${RESET}"

  read -p "Activer MySQL ? (y/n) : " ENABLE
  [[ "$ENABLE" != "y" ]] && continue

  read -p "Database : " DB
  read -p "Utilisateur : " DB_USER
  read -s -p "Mot de passe : " DB_PASS
  echo

  backup_file "$CONFIG"
  MODIFIED_FILES+=("$CONFIG")

  "$YQ" e '.' "$CONFIG" >/dev/null

  # =========================
  # JOBS
  # =========================

  if [[ "$plugin" == "Jobs" ]]; then

    "$YQ" -i '.storage.method = "mysql"' "$CONFIG"

    if "$YQ" e '.mysql' "$CONFIG" >/dev/null 2>&1; then
      "$YQ" -i '.mysql.username = "'"$DB_USER"'"' "$CONFIG"
      "$YQ" -i '.mysql.password = "'"$DB_PASS"'"' "$CONFIG"
      "$YQ" -i '.mysql.hostname = "localhost"' "$CONFIG"
      "$YQ" -i '.mysql.port = "3306"' "$CONFIG"
      "$YQ" -i '.mysql.database = "'"$DB"'"' "$CONFIG"
    fi

  fi

  # =========================
  # LUCKPERMS
  # =========================

  if [[ "$plugin" == "LuckPerms" ]]; then

    if "$YQ" e '.storage.method' "$CONFIG" >/dev/null 2>&1; then
      "$YQ" -i '.storage.method = "mysql"' "$CONFIG"
    fi

    if "$YQ" e '.data' "$CONFIG" >/dev/null 2>&1; then
      "$YQ" -i '.data.address = "localhost"' "$CONFIG"
      "$YQ" -i '.data.database = "'"$DB"'"' "$CONFIG"
      "$YQ" -i '.data.username = "'"$DB_USER"'"' "$CONFIG"
      "$YQ" -i '.data.password = "'"$DB_PASS"'"' "$CONFIG"
    fi

  fi

  # =========================
  # TOWNY
  # =========================

  if [[ "$plugin" == "Towny" ]]; then

    if "$YQ" e '.database_load' "$CONFIG" >/dev/null 2>&1; then
      "$YQ" -i '.database_load = "mysql"' "$CONFIG"
      "$YQ" -i '.database_save = "mysql"' "$CONFIG"
    fi

    if "$YQ" e '.database.sql.hostname' "$CONFIG" >/dev/null 2>&1; then
      "$YQ" -i '.database.sql.hostname = "localhost"' "$CONFIG"
      "$YQ" -i '.database.sql.port = 3306' "$CONFIG"
      "$YQ" -i '.database.sql.dbname = "'"$DB"'"' "$CONFIG"
      "$YQ" -i '.database.sql.username = "'"$DB_USER"'"' "$CONFIG"
      "$YQ" -i '.database.sql.password = "'"$DB_PASS"'"' "$CONFIG"
    fi

  fi

# =========================
# AURASKILLS
# =========================

if [[ "$plugin" == "AuraSkills" ]]; then

  "$YQ" -i '.sql.enabled = true' "$CONFIG"
  "$YQ" -i '.sql.type = "mysql"' "$CONFIG"
  "$YQ" -i '.sql.host = "localhost"' "$CONFIG"
  "$YQ" -i '.sql.port = 3306' "$CONFIG"
  "$YQ" -i '.sql.database = "'"$DB"'"' "$CONFIG"
  "$YQ" -i '.sql.username = "'"$DB_USER"'"' "$CONFIG"
  "$YQ" -i '.sql.password = "'"$DB_PASS"'"' "$CONFIG"

fi

  # =========================
  # VALIDATION YAML
  # =========================

  if ! "$YQ" e '.' "$CONFIG" >/dev/null 2>&1; then
    echo -e "${RED}Erreur YAML après modification.${RESET}"
    exit 1
  fi

  echo -e "${GREEN}✔ $plugin configuré${RESET}"

done

# ==================================================
# FINAL TEST
# ==================================================

mysql -u root -p"$ROOT_PASS" -e "SELECT 1;" >/dev/null 2>&1 || true

systemctl restart minecraft.service 2>/dev/null || true

echo -e "${GREEN}"
echo "=================================================="
echo "      INSTALLATION TERMINÉE AVEC SUCCÈS"
echo "=================================================="
echo -e "${RESET}"