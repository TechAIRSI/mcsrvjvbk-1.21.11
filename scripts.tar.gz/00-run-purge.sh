#!/bin/bash

set -e  # Arrête immédiatement en cas d'erreur

SCRIPTS_DIR="/scripts-purge"

# Vérification existence des scripts
if [[ ! -f "$SCRIPTS_DIR/01-mariadb-purge.sh" ]]; then
    echo "ERREUR : 01-mariadb-purge.sh introuvable"
    exit 1
fi

if [[ ! -f "$SCRIPTS_DIR/02-minecraft-purge.sh" ]]; then
    echo "ERREUR : 02-minecraft-purge.sh introuvable"
    exit 1
fi

# Exécution 01
echo "Exécution : 01-mariadb-purge.sh"
bash "$SCRIPTS_DIR/01-mariadb-purge.sh"

# Exécution 00 uniquement si 01 s'est terminé sans erreur
echo "Exécution : 02-minecraft-purge.sh"
bash "$SCRIPTS_DIR/02-minecraft-purge.sh"

echo "Terminé avec succès."