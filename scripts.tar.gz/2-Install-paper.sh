#!/bin/bash

# ==============================
#  TELECHARGEMENT PAPER (AUTO NOM)
# ==============================

RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
BLUE="\e[34m"
RESET="\e[0m"

if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Exécution en root requise.${RESET}"
  exit 1
fi

# Création de l'environnement serveur si nécessaire
echo -e "${BLUE}Vérification de l'environnement serveur...${RESET}"
mkdir -p /opt/minecraft
cd /opt/minecraft || exit 1

echo -e "${BLUE}Collez l'URL de téléchargement Paper :${RESET}"
read -r URL

if [ -z "$URL" ]; then
  echo -e "${RED}URL vide.${RESET}"
  exit 1
fi

# Extraction du nom de fichier depuis l'URL
FILENAME=$(basename "$URL")

echo -e "${YELLOW}Téléchargement de $FILENAME ...${RESET}"

if wget "$URL" -O "$FILENAME"; then
    echo -e "${GREEN}Etat : Terminée avec succès${RESET}"
else
    echo -e "${RED}Etat : Echec du téléchargement${RESET}"
    exit 1
fi

echo -e "${BLUE}Fichier enregistré : /opt/minecraft/$FILENAME${RESET}"