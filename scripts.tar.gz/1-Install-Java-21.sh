#!/bin/bash

# ==============================
#  INSTALLATION JAVA 21 TEMURIN
# ==============================

# ----- Couleurs -----
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
BLUE="\e[34m"
RESET="\e[0m"

# ----- Fonction affichage -----
run_task() {
    TASK_NAME="$1"
    shift

    echo -e "${BLUE}Tâche : ${TASK_NAME}${RESET}"
    echo -e "${YELLOW}Etat : En cours...${RESET}"

    if "$@" > /dev/null 2>&1; then
        echo -e "${GREEN}Etat : Terminée avec succès${RESET}"
    else
        echo -e "${RED}Etat : Echec${RESET}"
        exit 1
    fi

    echo
}

# ----- Vérification root -----
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Ce script doit être exécuté en root.${RESET}"
  exit 1
fi

echo -e "${BLUE}===== Installation Java 21 Temurin =====${RESET}"
echo

# 1. Suppression ancienne config
run_task "Suppression ancienne clé Adoptium" rm -f /etc/apt/keyrings/adoptium.gpg
run_task "Suppression ancien dépôt Adoptium" rm -f /etc/apt/sources.list.d/adoptium.list

# 2. Installation prérequis
run_task "Installation des dépendances (gnupg, wget, certificats)" \
apt install -y ca-certificates wget gnupg

# 3. Création dossier keyrings
run_task "Création du dossier /etc/apt/keyrings" mkdir -p /etc/apt/keyrings

# 4. Téléchargement clé GPG
run_task "Téléchargement clé Adoptium" \
wget https://packages.adoptium.net/artifactory/api/gpg/key/public -O /tmp/adoptium.asc

# 5. Conversion clé
run_task "Conversion clé en format binaire" \
gpg --dearmor /tmp/adoptium.asc

run_task "Installation clé système" \
mv /tmp/adoptium.asc.gpg /etc/apt/keyrings/adoptium.gpg

run_task "Définition permissions clé" \
chmod 644 /etc/apt/keyrings/adoptium.gpg

# 6. Ajout dépôt
run_task "Ajout dépôt Adoptium" \
bash -c 'echo "deb [signed-by=/etc/apt/keyrings/adoptium.gpg arch=amd64] https://packages.adoptium.net/artifactory/deb bookworm main" > /etc/apt/sources.list.d/adoptium.list'

# 7. Mise à jour APT
run_task "Mise à jour des dépôts" apt update

# 8. Installation Java 21
run_task "Installation Temurin 21 JRE" apt install -y temurin-21-jre

# 9. Vérification version
echo -e "${BLUE}Tâche : Vérification version Java${RESET}"
echo -e "${YELLOW}Etat : En cours...${RESET}"

JAVA_VERSION=$(java -version 2>&1 | head -n 1)

if echo "$JAVA_VERSION" | grep -q "21"; then
    echo -e "${GREEN}Etat : Terminée avec succès${RESET}"
    echo -e "${GREEN}Version détectée : $JAVA_VERSION${RESET}"
else
    echo -e "${RED}Etat : Echec - Java 21 non détecté${RESET}"
    exit 1
fi

echo
echo -e "${GREEN}===== Installation terminée correctement =====${RESET}"