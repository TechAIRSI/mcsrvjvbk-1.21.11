#!/bin/bash

# ==============================
#  PURGE COMPLETE MINECRAFT + JAVA 21
# ==============================

RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
RESET="\e[0m"

if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Exécution en root requise.${RESET}"
  exit 1
fi

echo -e "${RED}ATTENTION : Cette action va supprimer Minecraft, le service, UFW, Java 21 et les dépôts associés.${RESET}"
echo -e "${YELLOW}Tapez OUI pour confirmer :${RESET}"
read -r CONFIRM

if [ "$CONFIRM" != "OUI" ]; then
  echo -e "${RED}Opération annulée.${RESET}"
  exit 1
fi

# ==============================
# Arrêt service Minecraft
# ==============================

echo -e "${YELLOW}Arrêt du service Minecraft...${RESET}"
systemctl stop minecraft 2>/dev/null
systemctl disable minecraft 2>/dev/null

rm -f /etc/systemd/system/minecraft.service
systemctl daemon-reload

# ==============================
# Suppression dossiers
# ==============================

echo -e "${YELLOW}Suppression des dossiers...${RESET}"
rm -rf /opt/minecraft
rm -rf /opt/scripts

# ==============================
# Reset firewall
# ==============================

echo -e "${YELLOW}Reset UFW...${RESET}"
if command -v ufw >/dev/null 2>&1; then
  ufw --force reset
fi

# ==============================
# Suppression Java 21
# ==============================

echo -e "${YELLOW}Suppression des paquets Java 21...${RESET}"

apt remove --purge -y temurin-21-jre openjdk-21-jre-headless openjdk-21-jre 2>/dev/null
apt autoremove -y
apt autoclean

# ==============================
# Suppression dépôts Adoptium
# ==============================

echo -e "${YELLOW}Suppression des dépôts Java...${RESET}"

rm -f /etc/apt/sources.list.d/adoptium.list
rm -f /etc/apt/keyrings/adoptium.gpg

apt update

echo -e "${GREEN}Purge complète terminée avec succès.${RESET}"