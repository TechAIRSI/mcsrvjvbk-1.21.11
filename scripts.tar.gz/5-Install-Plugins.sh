#!/bin/bash

# Couleurs
RED="\e[31m"
GREEN="\e[32m"
BLUE="\e[34m"
YELLOW="\e[33m"
RESET="\e[0m"

SERVICE="minecraft.service"

DEST_DIR="/opt/minecraft/plugins"
ARCHIVE_NAME="Plugins.tar.gz"

# Demande URL
read -rp "Veuillez entrer l'URL du fichier Plugins.tar.gz : " URL

if [[ -z "$URL" ]]; then
    echo -e "${RED}Erreur : URL non fournie.${RESET}"
    exit 1
fi

echo -e "${BLUE}Redémarrage du serveur Minecraft...${RESET}"
systemctl restart $SERVICE

echo -e "${BLUE}Attente de la création du dossier plugins...${RESET}"

while [ ! -d "$DEST_DIR" ]; do
    sleep 3
done

echo -e "${GREEN}Dossier plugins détecté.${RESET}"

cd "$DEST_DIR" || {
    echo -e "${RED}Impossible d'accéder au dossier.${RESET}"
    exit 1
}

echo -e "${BLUE}Téléchargement en cours...${RESET}"
if ! wget -q --show-progress -O "$ARCHIVE_NAME" "$URL"; then

    echo -e "${RED}Téléchargement échoué.${RESET}"
    exit 1
fi

echo -e "${BLUE}Extraction en cours...${RESET}"
if ! tar -xzf "$ARCHIVE_NAME" -C "$DEST_DIR"; then

    echo -e "${RED}Erreur lors de l'extraction.${RESET}"
    exit 1
fi

# Déplacement de MCXboxBroadcastExtension.jar vers /tmp

if [ -f "$DEST_DIR/MCXboxBroadcastExtension.jar" ]; then
    echo -e "${BLUE}Déplacement de MCXboxBroadcastExtension.jar vers /tmp...${RESET}"
    mv "$DEST_DIR/MCXboxBroadcastExtension.jar" /tmp/
else
    echo -e "${RED}MCXboxBroadcastExtension.jar introuvable.${RESET}"
fi

echo -e "${BLUE}Suppression de l'archive...${RESET}"
rm -f "$DEST_DIR/$ARCHIVE_NAME"

if [[ $? -ne 0 ]]; then
    echo -e "${RED}Impossible de supprimer l'archive.${RESET}"
    exit 1
fi

echo -e "${GREEN}Installation terminée avec succès.${RESET}"

echo -e "${YELLOW}Redémarrage du serveur...${RESET}"
systemctl restart $SERVICE