#!/bin/bash

# ==============================
#  SETUP SYSTEMD ONLY
# ==============================

RED="\e[31m"
GREEN="\e[32m"
BLUE="\e[34m"
RESET="\e[0m"

if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Exécution en root requise.${RESET}"
  exit 1
fi

# Vérification wget
if ! command -v wget >/dev/null 2>&1; then
  apt update -y
  apt install -y wget
fi

# Vérifie que le dossier existe
if [ ! -d /opt/minecraft ]; then
  echo -e "${RED}/opt/minecraft n'existe pas.${RESET}"
  exit 1
fi

# ==============================
# Création utilisateur minecraft
# ==============================

if id "minecraft" &>/dev/null; then
  echo -e "${BLUE}Utilisateur minecraft déjà existant.${RESET}"
else
  echo -e "${BLUE}Création de l'utilisateur minecraft...${RESET}"
  useradd -r -m -d /opt/minecraft -s /bin/bash minecraft
fi

echo -e "${BLUE}Attribution des permissions...${RESET}"
chown -R minecraft:minecraft /opt/minecraft
chown -R minecraft:minecraft /opt/scripts


# ==============================
# Vérifications
# ==============================


cd /opt/minecraft || exit 1

# Vérifie présence du jar
if ! ls *.jar 1> /dev/null 2>&1; then
  echo -e "${RED}Aucun fichier .jar trouvé dans /opt/minecraft.${RESET}"
  exit 1
fi

JAR_FILE=$(ls *.jar | head -n 1)

# Vérifie dossier scripts
if [ ! -d /opt/scripts ]; then
  echo -e "${RED}/opt/scripts n'existe pas.${RESET}"
  exit 1
fi

# ==============================
# Création EULA
# ==============================

# Création automatique de l'EULA
echo -e "${BLUE}Acceptation de la licence...${RESET}"
echo "eula=true" > eula.txt

echo -e "${BLUE}Création du start.sh...${RESET}"

cat > /opt/scripts/start.sh <<EOF
#!/bin/bash
cd /opt/minecraft
java -Xms8G -Xmx12G -jar $JAR_FILE nogui
EOF

chmod +x /opt/scripts/start.sh

echo -e "${BLUE}Création du service systemd...${RESET}"

cat > /etc/systemd/system/minecraft.service <<EOF
[Unit]
Description=Minecraft Paper Server
After=network.target

[Service]
User=minecraft
Group=minecraft
WorkingDirectory=/opt/minecraft
ExecStart=/opt/scripts/start.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable minecraft
systemctl restart minecraft

if systemctl is-active --quiet minecraft; then
    echo -e "${GREEN}Serveur démarré avec succès.${RESET}"
else
    echo -e "${RED}Echec du démarrage.${RESET}"
    exit 1
fi