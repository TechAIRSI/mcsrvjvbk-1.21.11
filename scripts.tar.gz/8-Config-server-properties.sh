#!/bin/bash

SERVICE="minecraft.service"
SERVER_PROPERTIES="/opt/minecraft/server.properties"

WORLD="/opt/minecraft/world"
WORLD_NETHER="/opt/minecraft/world_nether"
WORLD_END="/opt/minecraft/world_the_end"

GREEN="\e[32m"
BLUE="\e[34m"
RED="\e[31m"
NC="\e[0m"

echo -e "${BLUE}Arrêt du serveur Minecraft...${NC}"
systemctl stop $SERVICE

echo -e "${BLUE}Suppression des mondes existants...${NC}"

if [ -d "$WORLD" ]; then
    rm -rf "$WORLD"
    echo -e "${GREEN}world supprimé${NC}"
fi

if [ -d "$WORLD_NETHER" ]; then
    rm -rf "$WORLD_NETHER"
    echo -e "${GREEN}world_nether supprimé${NC}"
fi

if [ -d "$WORLD_END" ]; then
    rm -rf "$WORLD_END"
    echo -e "${GREEN}world_the_end supprimé${NC}"
fi

echo
echo -e "${BLUE}Configuration du nouveau monde${NC}"

read -p "Nom du monde (level-name) : " LEVEL_NAME
read -p "Seed du monde (level-seed) : " LEVEL_SEED
read -p "Difficulté (peaceful/easy/normal/hard) : " DIFFICULTY

echo -e "${BLUE}Modification du fichier server.properties...${NC}"

sed -i "s/^level-name=.*/level-name=$LEVEL_NAME/" $SERVER_PROPERTIES
sed -i "s/^level-seed=.*/level-seed=$LEVEL_SEED/" $SERVER_PROPERTIES
sed -i "s/^difficulty=.*/difficulty=$DIFFICULTY/" $SERVER_PROPERTIES

echo -e "${GREEN}Configuration appliquée${NC}"

echo -e "${BLUE}Redémarrage du serveur Minecraft...${NC}"
systemctl restart $SERVICE

echo -e "${GREEN}Serveur redémarré. Nouveau monde généré au prochain démarrage.${NC}"