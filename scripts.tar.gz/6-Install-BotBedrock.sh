#!/bin/bash

# ==============================
#  INSTALL + CONFIG MCXBOX
# ==============================

RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
RESET="\e[0m"

if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Exécution en root requise.${RESET}"
  exit 1
fi

TARGET_DIR="/opt/minecraft/plugins/Geyser-Spigot/extensions"
CONFIG_FILE="$TARGET_DIR/mcxboxbroadcast/config.yml"

TIMEOUT=120
ELAPSED=0

# ==============================
# Attente dossier extensions
# ==============================

echo -e "${CYAN}Attente du dossier extensions...${RESET}"

while [ ! -d "$TARGET_DIR" ]; do
    sleep 2
    ELAPSED=$((ELAPSED+2))

    if [ "$ELAPSED" -ge "$TIMEOUT" ]; then
        echo -e "${RED}Timeout : dossier extensions non détecté.${RESET}"
        exit 1
    fi
done

echo -e "${GREEN}Dossier extensions détecté.${RESET}"

# ==============================
# Vérification du fichier local
# ==============================

LOCAL_JAR="/tmp/MCXboxBroadcastExtension.jar"

if [ ! -f "$LOCAL_JAR" ]; then
  echo -e "${RED}Erreur : MCXboxBroadcastExtension.jar introuvable dans /tmp/.${RESET}"
  exit 1
fi

echo -e "${YELLOW}Copie de l'extension depuis /tmp...${RESET}"

if ! cp "$LOCAL_JAR" "$TARGET_DIR/"; then
  echo -e "${RED}Erreur lors de la copie de l'extension.${RESET}"
  exit 1
fi

# ==============================
# Premier redémarrage
# ==============================

echo -e "${YELLOW}Redémarrage du serveur...${RESET}"
if ! systemctl restart minecraft.service; then
  echo -e "${RED}Erreur lors du redémarrage du service.${RESET}"
  exit 1
fi

# ==============================
# Attente du config.yml
# ==============================

echo -e "${CYAN}Attente de la création du config.yml...${RESET}"

TIMEOUT=60
ELAPSED=0

while [ ! -f "$CONFIG_FILE" ]; do
    sleep 2
    ELAPSED=$((ELAPSED+2))

    if [ "$ELAPSED" -ge "$TIMEOUT" ]; then
        echo -e "${RED}Timeout : config.yml non détecté.${RESET}"
        exit 1
    fi
done

echo -e "${GREEN}config.yml détecté.${RESET}"

# ==============================
# Configuration
# ==============================

if [ ! -f "$CONFIG_FILE" ]; then
  echo -e "${RED}Fichier config.yml introuvable.${RESET}"
  exit 1
fi

echo -e "${CYAN}Entrez la valeur pour remote-address :${RESET}"
read -r REMOTE_ADDRESS

echo -e "${CYAN}Entrez la valeur pour remote-port :${RESET}"
read -r REMOTE_PORT

if [ -z "$REMOTE_ADDRESS" ] || [ -z "$REMOTE_PORT" ]; then
  echo -e "${RED}Valeurs invalides.${RESET}"
  exit 1
fi

# Sauvegarde
cp "$CONFIG_FILE" "$CONFIG_FILE.bak"

# Modification propre avec sed
sed -i "s/^ *remote-address: .*/  remote-address: $REMOTE_ADDRESS/" "$CONFIG_FILE"
sed -i "s/^ *remote-port: .*/  remote-port: $REMOTE_PORT/" "$CONFIG_FILE"

echo -e "${GREEN}Configuration mise à jour.${RESET}"

# ==============================
# Second redémarrage
# ==============================

echo -e "${YELLOW}Redémarrage final du serveur...${RESET}"
systemctl restart minecraft.service

if systemctl is-active --quiet minecraft; then
    echo -e "${GREEN}Installation et configuration terminées avec succès.${RESET}"
else
    echo -e "${RED}Erreur : le service ne démarre pas.${RESET}"
    exit 1
fi