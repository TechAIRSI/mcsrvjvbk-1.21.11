#!/bin/bash

# ==============================
#  OUTIL DE PURGE MARIADB
# ==============================

# Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Vérification root
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[ERREUR]${NC} Exécutez ce script en root."
  exit 1
fi

clear
echo -e "${BLUE}======================================${NC}"
echo -e "${BLUE}        OUTIL DE PURGE MARIADB        ${NC}"
echo -e "${BLUE}======================================${NC}"
echo

echo -e "${YELLOW}Choisissez une option :${NC}"
echo "1) Purge complète des bases de données"
echo "2) Purge complète des utilisateurs (hors root)"
echo "3) Purge bases + utilisateurs"
echo "4) Désinstallation complète (MariaDB + yq)"
echo
read -p "Votre choix (1-4) : " choice

echo
read -p "Confirmer l'opération (oui/non) : " confirm

if [[ "$confirm" != "oui" ]]; then
  echo -e "${RED}Opération annulée.${NC}"
  exit 0
fi

case $choice in

1)
  echo -e "${BLUE}[INFO] Purge des bases...${NC}"
  systemctl stop mariadb
  mysql -u root -e "
  SET FOREIGN_KEY_CHECKS=0;
  SELECT CONCAT('DROP DATABASE \`', schema_name, '\`;')
  FROM information_schema.schemata
  WHERE schema_name NOT IN ('mysql','information_schema','performance_schema','sys');
  " | tail -n +2 | mysql -u root
  echo -e "${GREEN}Bases supprimées.${NC}"
  ;;

2)
  echo -e "${BLUE}[INFO] Suppression des utilisateurs...${NC}"
  systemctl stop mariadb
  mysql -u root -e "
  DELETE FROM mysql.user
  WHERE User NOT IN ('root');
  FLUSH PRIVILEGES;
  "
  echo -e "${GREEN}Utilisateurs supprimés.${NC}"
  ;;

3)
  echo -e "${BLUE}[INFO] Purge bases + utilisateurs...${NC}"
  systemctl stop mariadb

  mysql -u root -e "
  SET FOREIGN_KEY_CHECKS=0;
  SELECT CONCAT('DROP DATABASE \`', schema_name, '\`;')
  FROM information_schema.schemata
  WHERE schema_name NOT IN ('mysql','information_schema','performance_schema','sys');
  " | tail -n +2 | mysql -u root

  mysql -u root -e "
  DELETE FROM mysql.user
  WHERE User NOT IN ('root');
  FLUSH PRIVILEGES;
  "

  echo -e "${GREEN}Bases et utilisateurs supprimés.${NC}"
  ;;

4)
  echo -e "${BLUE}[INFO] Désinstallation complète...${NC}"

  systemctl stop mariadb
  systemctl disable mariadb

  apt-get purge mariadb-server mariadb-client mariadb-common -y
  apt-get autoremove -y
  apt-get autoclean

  # Suppression fichiers MariaDB
  rm -rf /etc/mysql
  rm -rf /var/lib/mysql
  rm -rf /var/log/mysql

  # Suppression de yq installé manuellement
  if [ -f /usr/local/bin/yq ]; then
      rm -f /usr/local/bin/yq
      echo -e "${GREEN}yq (installé manuellement) supprimé.${NC}"
  else
      echo -e "${YELLOW}yq non trouvé dans /usr/local/bin.${NC}"
  fi

    if [ -f /usr/bin/yq ]; then
      rm -f /usr/bin/yq
      echo -e "${GREEN}yq (installé manuellement) supprimé.${NC}"
  else
      echo -e "${YELLOW}yq non trouvé dans /usr/bin.${NC}"
  fi

  systemctl status mariadb

  echo -e "${GREEN}MariaDB et yq complètement supprimés.${NC}"
  ;;

*)
  echo -e "${RED}Choix invalide.${NC}"
  exit 1
  ;;

esac

echo
echo -e "${GREEN}Opération terminée.${NC}"