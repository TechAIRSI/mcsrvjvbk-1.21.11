#!/bin/bash

# ==============================
#  FIREWALL SETUP (UFW)
# ==============================

RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
MAGENTA="\e[35m"
RESET="\e[0m"

if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Exécution en root requise.${RESET}"
  exit 1
fi

run_task() {
    NAME="$1"
    shift

    echo -e "${CYAN}Tâche : ${NAME}${RESET}"
    echo -e "${YELLOW}Etat : En cours...${RESET}"

    if "$@" > /dev/null 2>&1; then
        echo -e "${GREEN}Etat : Terminée avec succès${RESET}"
    else
        echo -e "${RED}Etat : Echec${RESET}"
        exit 1
    fi

    echo
}

# Installation UFW si nécessaire
run_task "Installation de UFW" apt install -y ufw

# Activation des ports nécessaires
run_task "Ouverture port 22 TCP (SSH)" ufw allow 22/tcp
run_task "Ouverture port 25565 TCP (Minecraft Java)" ufw allow 25565/tcp
run_task "Ouverture port 25575 TCP (RCON)" ufw allow 25575/tcp
run_task "Ouverture port 19132 UDP (Minecraft Bedrock)" ufw allow 19132/udp

# Activation du firewall si non actif
if ufw status | grep -q "Status: inactive"; then
    run_task "Activation du firewall UFW" ufw --force enable
else
    echo -e "${MAGENTA}UFW déjà actif.${RESET}"
fi

echo -e "${GREEN}Configuration firewall terminée.${RESET}"