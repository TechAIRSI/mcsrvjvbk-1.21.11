#!/bin/bash

SERVICE="minecraft.service"
SERVER_PROPERTIES="/opt/minecraft/server.properties"
GEYSER_CONFIG="/opt/minecraft/plugins/Geyser-Spigot/config.yml"

echo -e "\e[34mRedémarrage initial du service Minecraft...\e[0m"
systemctl restart $SERVICE

sleep 5

if [ ! -f "$SERVER_PROPERTIES" ]; then
    echo -e "\e[31mErreur : server.properties introuvable\e[0m"
    exit 1
fi

echo -e "\e[34mConfiguration du RCON...\e[0m"

read -p "Mot de passe RCON : " RCON_PASS
echo
read -p "Confirmation : " RCON_PASS_CONFIRM
echo

if [ "$RCON_PASS" != "$RCON_PASS_CONFIRM" ]; then
    echo -e "\e[31mLes mots de passe ne correspondent pas\e[0m"
    exit 1
fi

sed -i "s/^enable-rcon=.*/enable-rcon=true/" "$SERVER_PROPERTIES"
sed -i "s/^rcon.port=.*/rcon.port=25575/" "$SERVER_PROPERTIES"

if grep -q "^rcon.password=" "$SERVER_PROPERTIES"; then
    sed -i "s/^rcon.password=.*/rcon.password=$RCON_PASS/" "$SERVER_PROPERTIES"
else
    echo "rcon.password=$RCON_PASS" >> "$SERVER_PROPERTIES"
fi

echo -e "\e[32mRCON configuré\e[0m"

if [ ! -f "$GEYSER_CONFIG" ]; then
    echo -e "\e[31mErreur : config.yml de Geyser introuvable\e[0m"
    exit 1
fi

echo -e "\e[34mModification de la configuration Geyser...\e[0m"

sed -i "s/auth-type:.*/auth-type: floodgate/" "$GEYSER_CONFIG"

echo -e "\e[32mConfiguration Geyser mise à jour\e[0m"

echo -e "\e[34mRedémarrage final du service Minecraft...\e[0m"
systemctl restart $SERVICE

echo -e "\e[32mServeur redémarré et configuration appliquée\e[0m"